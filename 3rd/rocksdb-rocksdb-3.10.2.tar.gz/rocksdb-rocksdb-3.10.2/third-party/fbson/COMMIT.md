fbson commit: 
https://github.com/facebook/mysql-5.6/commit/4cfccf14f4abc5a142b25c54ce1d0f4dafe95f9c
